package com.example.administrator.myapplication;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;

import static android.support.v4.os.LocaleListCompat.create;

public class Main3Activity extends AppCompatActivity {

    TextView textView;
    Switch aSwitch;
    TextView textView2;
    RadioGroup radioGroup;
    RadioButton radioButton , radioButton2 , radioButton3 ;
    ImageButton imageButton, imageButton2, imageButton3;
    Button button_exit;
    Button button_restart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        textView = (TextView)findViewById(R.id.textView);
        textView2 = (TextView)findViewById(R.id.textView2);
        aSwitch = (Switch)findViewById(R.id.switch1);
        radioGroup = (RadioGroup)findViewById(R.id.radioGroup);
        radioButton = (RadioButton)findViewById(R.id.radioButton);
        radioButton2 = (RadioButton)findViewById(R.id.radioButton2);
        radioButton3 = (RadioButton)findViewById(R.id.radioButton3);
        imageButton=(ImageButton)findViewById(R.id.imageButton);
        imageButton2=(ImageButton)findViewById(R.id.imageButton2);
        imageButton3=(ImageButton)findViewById(R.id.imageButton3);
        button_exit=(Button)findViewById(R.id.button);
        button_restart=(Button)findViewById(R.id.button2);


        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(aSwitch.isChecked()){
                    textView2.setVisibility(View.VISIBLE);
                    radioGroup.setVisibility(View.VISIBLE);
                    radioButton.setVisibility(View.VISIBLE);
                    radioButton2.setVisibility(View.VISIBLE);
                    radioButton3.setVisibility(View.VISIBLE);
                }else{
                    textView2.setVisibility(View.INVISIBLE);
                    radioGroup.setVisibility(View.INVISIBLE);
                    imageButton.setVisibility(View.INVISIBLE);
                    imageButton2.setVisibility(View.INVISIBLE);
                    imageButton3.setVisibility(View.INVISIBLE);
                    radioButton.setChecked(false);
                    radioButton2.setChecked(false);
                    radioButton3.setChecked(false);


                }
            }
        });

        radioButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(radioButton.isChecked()){
                    imageButton.setVisibility(View.VISIBLE);
                }else{
                    imageButton.setVisibility(View.INVISIBLE);
                }
            }
        });
        radioButton2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(radioButton2.isChecked()){
                    imageButton2.setVisibility(View.VISIBLE);
                }else{
                    imageButton2.setVisibility(View.INVISIBLE);
                }
            }
        });

        radioButton3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(radioButton3.isChecked()){
                    imageButton3.setVisibility(View.VISIBLE);
                }else{
                    imageButton3.setVisibility(View.INVISIBLE);

                }
            }
        });

        button_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                return;
            }
        });

        button_restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                aSwitch.setChecked(false);
                return;
            }
        });

    }
}
