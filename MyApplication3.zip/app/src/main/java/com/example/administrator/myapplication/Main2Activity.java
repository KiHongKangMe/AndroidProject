package com.example.administrator.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    CheckBox checkBox;
    TextView textView;
    RadioGroup radioGroup;
    RadioButton radioButton, radioButton2, radioButton3;
    ImageView imageView, imageView2, imageView3;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        checkBox = (CheckBox)findViewById(R.id.cb);
        textView = (TextView)findViewById(R.id.tV2);
        radioGroup=(RadioGroup)findViewById(R.id.rGrup);
        radioButton = (RadioButton)findViewById(R.id.rb1);
        radioButton2 = (RadioButton)findViewById(R.id.rb2);
        radioButton3 = (RadioButton)findViewById(R.id.rb3);
        imageView = (ImageView)findViewById(R.id.imageView);
        imageView2 = (ImageView)findViewById(R.id.imageView2);
        imageView3 = (ImageView)findViewById(R.id.imageView3);


        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (checkBox.isChecked()){
                    textView.setVisibility(android.view.View.VISIBLE);
                    radioGroup.setVisibility(View.VISIBLE);
                }else{
                    textView.setVisibility(View.INVISIBLE);
                    radioGroup.setVisibility(View.INVISIBLE);
                    imageView.setVisibility(View.INVISIBLE);
                    imageView2.setVisibility(View.INVISIBLE);
                    imageView3.setVisibility(View.INVISIBLE);
                }
            }
        });



        radioButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (radioButton.isChecked()){
                    imageView.setVisibility(android.view.View.VISIBLE);
                }else{
                    imageView.setVisibility(View.INVISIBLE);

                }
            }
        });
        radioButton2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (radioButton2.isChecked()){
                    imageView2.setVisibility(android.view.View.VISIBLE);
                }else{
                    imageView2.setVisibility(View.INVISIBLE);

                }
            }
        });
        radioButton3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (radioButton3.isChecked()){
                    imageView3.setVisibility(android.view.View.VISIBLE);
                }else{
                    imageView3.setVisibility(View.INVISIBLE);

                }
            }
        });


        button = (Button)findViewById(R.id.return1);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this, Main4Activity.class);
                startActivity(intent);
            }
        });










    }
}
